# Execution

Run python main.py
Requires python 3.6+

Use combiner.py and visualizer.py to generate the visualized results.